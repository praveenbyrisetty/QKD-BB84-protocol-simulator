import React, { useState, useRef } from 'react';
import './index.css'; 

// Components
import Loader from './Hack/Loader'; 
import Header from './Hack/Header';
import QuantumChannel from './Hack/QuantumChannel';
import AlicePanel from './Hack/AlicePanel';
import BobPanel from './Hack/BobPanel';
import GraphPage from './Hack/GraphPage';
import Controls from './Hack/Controls';
import CascadePanel from './Hack/CascadePanel';
import PrivacyAmpPanel from './Hack/PrivacyAmpPanel';
import EncryptionPanel from './Hack/EncryptionPanel';
import FixedBubble from './Hack/FixedBubble'; 
import QuantumChannelExpanded from './Hack/QuantumChannelExpanded';
import CascadeExpanded from './Hack/CascadeExpanded';
import PrivacyAmpExpanded from './Hack/PrivacyAmpExpanded';
import EncryptionExpanded from './Hack/EncryptionExpanded';


function App() {
  // --- STATE ---
  const [qubits, setQubits] = useState([]); 
  const [isEveOn, setIsEveOn] = useState(false);
  const [step, setStep] = useState(0); 
  const [numBits, setNumBits] = useState(20); 
  const [isLoading, setIsLoading] = useState(false); 
  
  // Backend Data
  const [backendData, setBackendData] = useState(null);
  const [finalKey, setFinalKey] = useState("");
  const [errorRate, setErrorRate] = useState(0);
  const [isAborted, setIsAborted] = useState(false);
  const [correctedKey, setCorrectedKey] = useState("");
  const [channelExpanded, setChannelExpanded] = useState(false);
  const [cascadeExpanded, setCascadeExpanded] = useState(false);
  const [privacyExpanded, setPrivacyExpanded] = useState(false);
  const [encryptionExpanded, setEncryptionExpanded] = useState(false);

  // INTERACTION STATE
  const [bubbleData, setBubbleData] = useState({ title: null, text: null, x: 0, y: 0 });
  const hoverTimer = useRef(null);

  // --- ACTIONS ---
  const handleTransmit = async () => {
    console.log('TRANSMIT clicked, numBits:', numBits, 'eve:', isEveOn);
    setIsLoading(true); setStep(0); setBackendData(null); setQubits([]); setIsAborted(false); setErrorRate(0); setFinalKey(""); setCorrectedKey("");
    try {
      const response = await fetch('http://127.0.0.1:5000/bb84', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ n: numBits, eve: isEveOn }), });
      const data = await response.json();
      console.log('Backend response:', data);
      setBackendData(data);
      const uiQubits = data.alice_bits.map((bit, i) => ({ id: i, aliceBit: bit, aliceBasis: data.alice_bases[i], bobBasis: data.bob_bases[i], bobBit: data.bob_results[i], }));
      setTimeout(() => { setQubits(uiQubits); setStep(1); setIsLoading(false); console.log('Step set to 1'); }, 1000);
    } catch (error) { console.error('FETCH ERROR:', error); alert("Backend Error"); setIsLoading(false); }
  };
  const handleSift = () => { console.log('SIFT clicked, backendData:', !!backendData); if(backendData) { setErrorRate(backendData.qber * 100); setStep(2); console.log('Step set to 2'); } };
  const handleCascade = () => { console.log('CASCADE clicked, backendData:', !!backendData, 'aborted:', backendData?.aborted); if(backendData) { if(backendData.aborted) setIsAborted(true); setCorrectedKey(backendData.alice_key ? backendData.alice_key.join('') : ""); setStep(3); console.log('Step set to 3'); } };
  const handlePrivacyAmp = () => { console.log('PRIVACY AMP clicked, isAborted:', isAborted, 'backendData:', !!backendData); if(!isAborted && backendData) { setFinalKey(backendData.final_key.join('')); setStep(4); console.log('Step set to 4'); } };
  const handleReset = () => { console.log('RESET clicked'); setQubits([]); setStep(0); setIsAborted(false); setFinalKey(""); setErrorRate(0); setBackendData(null); setChannelExpanded(false); setCascadeExpanded(false); setPrivacyExpanded(false); setEncryptionExpanded(false); };

  // --- NEW: DYNAMIC HOVER LOGIC ---
  const hoverProps = (title, text) => ({
    onMouseEnter: (e) => {
      const clientX = e.clientX;
      const clientY = e.clientY;
      if (hoverTimer.current) clearTimeout(hoverTimer.current);
      // Wait 1 second before showing explanation
      hoverTimer.current = setTimeout(() => {
        setBubbleData({ title: title, text: text, x: clientX, y: clientY });
      }, 1000); 
    },
    onMouseLeave: () => {
      if (hoverTimer.current) clearTimeout(hoverTimer.current);
      setBubbleData({ title: null, text: null, x: 0, y: 0 });
    },
    style: { 
      cursor: 'help',
      transition: 'all 0.3s ease',
      boxShadow: '0 0 0 0 rgba(99, 102, 241, 0)'
    },
    onMouseOver: (e) => {
      e.currentTarget.style.boxShadow = '0 0 15px rgba(99, 102, 241, 0.4)';
      e.currentTarget.style.transform = 'scale(1.01)';
    },
    onMouseOut: (e) => {
      e.currentTarget.style.boxShadow = '0 0 0 0 rgba(99, 102, 241, 0)';
      e.currentTarget.style.transform = 'scale(1)';
    }
  });

  // --- RENDER ---
  return (
    <div style={{minHeight: '100vh'}}>
      {isLoading && <Loader />}
      
      <Header isEveOn={isEveOn} setIsEveOn={setIsEveOn} step={step} onHelp={() => {}} />

      <main className="container">
        
        {/* CONFIG SECTION */}
        {step === 0 && !isLoading && (
          <div className="config-panel" {...hoverProps('Configuration', 'Use the slider to set how many qubits Alice will send to Bob.')}>
            <div style={{display:'flex', flexDirection:'column', alignItems:'center', width:'100%', maxWidth:'500px'}}>
              <div style={{display:'flex', justifyContent:'space-between', width:'100%', marginBottom:'10px'}}>
                <span className="config-label">Transmission Size:</span>
                <span style={{color:'#6366f1', fontWeight:'bold', fontFamily:'monospace', fontSize:'1.1rem'}}>{numBits} Qubits</span>
              </div>
              <div className="range-wrapper">
                <input type="range" min="10" max="500" value={numBits} onChange={(e) => setNumBits(parseInt(e.target.value))} className="custom-range"/>
              </div>
            </div>
          </div>
        )}

        <section>
          {channelExpanded ? (
            <QuantumChannelExpanded qubits={qubits} isEveOn={isEveOn} onClose={() => setChannelExpanded(false)} />
          ) : (
            <div {...hoverProps('Quantum Channel', 'The fiber optic cable where photons travel. Click to explore the equipment.')}>
              <QuantumChannel isTransmitting={step >= 1 && !isAborted} qubits={qubits} onExpand={() => setChannelExpanded(true)} />
            </div>
          )}
        </section>
        
        {/* ALICE & BOB PANELS - HIDDEN UNTIL TRANSMIT (step >= 1) */}
        {step >= 1 && (
          <section className="split-view" style={{marginBottom: '30px'}}>
             <div style={{height:'100%'}} {...hoverProps('Alice (The Sender)', 'Alice generates random bits and chooses random bases (+ or ×) to encode them as polarized photons. She sends these through the quantum channel to Bob.')}>
                <AlicePanel qubits={qubits} step={step} hoverProps={hoverProps} />
             </div>
             <div style={{height:'100%'}} {...hoverProps('Bob (The Receiver)', 'Bob independently picks random bases to measure the incoming photons. After sifting, only bits where his basis matched Alice\'s are kept as the raw key.')}>
                <BobPanel qubits={qubits} step={step} hoverProps={hoverProps} />
             </div>
          </section>
        )}

        {/* CASCADE & STATS */}
        {step >= 2 && (
          <section className={`stats-box ${isAborted ? 'aborted' : ''}`} {...(isAborted ? hoverProps('Protocol Aborted — Eve Detected', 'Eve must measure photons to eavesdrop, but this disturbs the quantum state and introduces errors. When the QBER exceeds ~11%, Alice and Bob detect the intrusion statistically and discard the compromised key.') : {})}>
             {isAborted ? (
                <div className="abort-container">
                  <div className="abort-icon">🚨</div>
                  <h2 className="abort-title">Protocol Aborted</h2>
                  <div className="abort-msg">Eavesdropper detected! Error Rate ({errorRate.toFixed(1)}%) too high.</div>
                </div>
             ) : (
                cascadeExpanded ? (
                  <CascadeExpanded siftedQubits={qubits} onClose={() => setCascadeExpanded(false)} />
                ) : (
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'30px', height:'420px'}}>
                  <div style={{height:'100%', cursor:'pointer'}} onClick={() => setCascadeExpanded(true)} {...hoverProps('Cascade Protocol', 'Alice and Bob split their sifted key into blocks and compare parity (even/odd). Click to see animated step-by-step!')}>
                     <CascadePanel siftedQubits={qubits} />
                  </div>
                  <div style={{height:'100%'}} {...hoverProps('QBER Graph', 'The blue line shows Alice\'s sifted key and the orange dashed line shows Bob\'s. Where the lines diverge, an error was introduced — usually by Eve\'s interception or channel noise.')}>
                     <GraphPage qubits={qubits} errorRate={errorRate} />
                  </div>
                </div>
                )
             )}
          </section>
        )}

        {/* PRIVACY AMP */}
        {step >= 3 && !isAborted && (
          <section>
            {privacyExpanded ? (
              <PrivacyAmpExpanded finalKey={step >= 4 ? backendData.final_key : ""} correctedKey={correctedKey} onClose={() => setPrivacyExpanded(false)} />
            ) : (
              <div style={{cursor:'pointer'}} onClick={() => setPrivacyExpanded(true)} {...hoverProps('Privacy Amplification', 'We shrink the key using a hash function to remove any partial info Eve stole. Click to see animated step-by-step!')}>
                <PrivacyAmpPanel finalKey={step >= 4 ? backendData.final_key : ""} correctedKey={correctedKey} />
              </div>
            )}
          </section>
        )}

        {/* ENCRYPTION */}
        {step >= 4 && !isAborted && (
          <section className="msg-area" style={{marginTop:'30px'}}>
            {encryptionExpanded ? (
              <EncryptionExpanded finalKey={backendData.final_key} onClose={() => setEncryptionExpanded(false)} />
            ) : (
              <div>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px'}}>
                  <h3 style={{textAlign:'center', color:'#6366f1', margin: 0, flex:1}} {...hoverProps('Secure Messaging', 'Using the final Quantum Key as a One-Time Pad to encrypt messages. Click the info button to see how it works!')}>Secure Messaging</h3>
                  <button onClick={() => setEncryptionExpanded(true)} style={{
                    background: 'linear-gradient(135deg, rgba(99,102,241,0.15), rgba(99,102,241,0.05))',
                    border: '1px solid #6366f140', color: '#c7d2fe', fontSize: '0.7rem',
                    padding: '5px 14px', borderRadius: '8px', cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}>🔍 How It Works</button>
                </div>
                <EncryptionPanel finalKey={backendData.final_key} />
              </div>
            )}
          </section>
        )}
      </main>

      <Controls step={step} isAborted={isAborted} actions={{ handleTransmit, handleSift, handleCascade, handlePrivacyAmp, handleReset }} />
      
      {/* THE UNIVERSAL BUBBLE */}
      <FixedBubble 
        title={bubbleData.title} 
        text={bubbleData.text} 
        x={bubbleData.x} 
        y={bubbleData.y} 
      />

    </div>
  );
}

export default App;